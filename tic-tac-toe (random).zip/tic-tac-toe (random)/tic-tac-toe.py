import re
from random import randint

_JUGADOR = "jugador"
_MAQUINA =  "maquina"

_SIMBOLO_JUGADOR = "x"
_SIMBOLO_MAQUINA = "o"

EMPATE = 0
JUGADOR_GANA = 1
MAQUINA_GANA = 2

class TicTacToe():
    def __init__(self):
        self.tablero = [None] * 9
        self.turno = _JUGADOR
        self.se_acabo_juego = False
        self.ganador = None

    def se_acabo(self): #TODO
        jugador_gana = self.verifique_jugador_gana()
        maquina_gana = self.verifique_maquina_gana()
        gana = None

        if jugador_gana:
            self.ganador = JUGADOR_GANA
            gana = True
        elif maquina_gana:
            self.ganador = MAQUINA_GANA
            gana = True
        elif (maquina_gana == False) and (jugador_gana == False) and (self.tablero.count(None) == 0):
            self.ganador = EMPATE
        else:
            gana = False
        return gana


    def verifique_jugador_gana(self):
        return all(i == _SIMBOLO_JUGADOR for i in self.tablero[0:3]) or \
               all(i == _SIMBOLO_JUGADOR for i in self.tablero[3:6]) or \
               all(i == _SIMBOLO_JUGADOR for i in self.tablero[6:9]) or \
               all(i == _SIMBOLO_JUGADOR for i in self.tablero[0:7:3]) or \
               all(i == _SIMBOLO_JUGADOR for i in self.tablero[1:8:3]) or \
               all(i == _SIMBOLO_JUGADOR for i in self.tablero[2:9:3]) or \
               all(i == _SIMBOLO_JUGADOR for i in self.tablero[::4]) or \
               all(i == _SIMBOLO_JUGADOR for i in self.tablero[2:7:2])


    def verifique_maquina_gana(self):
        return all(i == _SIMBOLO_MAQUINA for i in self.tablero[0:3]) or \
               all(i == _SIMBOLO_MAQUINA for i in self.tablero[3:6]) or \
               all(i == _SIMBOLO_MAQUINA for i in self.tablero[6:9]) or \
               all(i == _SIMBOLO_MAQUINA for i in self.tablero[0:7:3]) or \
               all(i == _SIMBOLO_MAQUINA for i in self.tablero[1:8:3]) or \
               all(i == _SIMBOLO_MAQUINA for i in self.tablero[2:9:3]) or \
               all(i == _SIMBOLO_MAQUINA for i in self.tablero[::4]) or \
               all(i == _SIMBOLO_MAQUINA for i in self.tablero[2:7:2])


    def jugar(self):
        if self.turno == _JUGADOR:
            self.turno_jugador()
            self.turno = _MAQUINA
        else:
            self.turno_maquina()
            self.turno = _JUGADOR

    def jugador_escoge_celda(self):
        print("Ingrese número de celda vacía entre 0 y 8")

        celda_jugador = input().strip()
        encuentra = re.search("\d", celda_jugador)

        if not encuentra:
            print("La entrada no es un número, por favor intente otra vez")

            return self.jugador_escoge_celda()

        celda_jugador = int(celda_jugador)

        if self.tablero[celda_jugador] is not None:
            print("La celda ya está ocupada, por favor intente otra vez")

            return self.jugador_escoge_celda()

        return celda_jugador



    def turno_jugador(self):
        celda_escogida = self.jugador_escoge_celda()
        self.tablero[celda_escogida] = _SIMBOLO_JUGADOR

    def turno_maquina(self):  # TODO: Finish this function by making the machine choose a random cell (use random module)
        acabo_turno = False
        while not acabo_turno:
            i = randint(0, 8)
            if self.tablero[i] is None:
                self.tablero[i] = _SIMBOLO_MAQUINA
                acabo_turno = True

    def formato_tablero(self):
        fila0 = "|".join(list(map(lambda c: " " if c is None else c, self.tablero[0:3])))
        fila1 = "|".join(list(map(lambda c: " " if c is None else c, self.tablero[3:6])))
        fila2 = "|".join(list(map(lambda c: " " if c is None else c, self.tablero[6:9])))

        return "\n".join([fila0, fila1, fila2])

    def print(self):
        print("Turno del jugador:" if self.turno == _MAQUINA else "Turno de la máquina:")
        print(self.formato_tablero())
        print()

    def imprimir_resultados(self):  # TODO: Finish this function in order to print the result based on the *winner*
        if self.ganador == EMPATE:
            print("Es un empate :)")
        elif self.ganador == JUGADOR_GANA:
            print("El jugador ha ganado :D")
        else:
            print("La máquina ha ganado :(")




if __name__ == '__main__':
    juego = TicTacToe()

    while not juego.se_acabo():
        juego.jugar()
        juego.print()

    juego.imprimir_resultados()



